let song, fft, amplitude;
let isPlaying = false, songLoaded = false;
let stars = [], connections = [];
let fileInput, uploadButton, playButton;
let audioUnlocked = false;

function setup() {
  createCanvas(windowWidth, windowHeight);
  fileInput = createFileInput(handleFile);
  fileInput.position(-9999, -9999);
  fileInput.attribute('accept', 'audio/*');

  uploadButton = createButton('🎺 Choose an Audio to Light the Stars');
  uploadButton.position(30, 30);
  styleButton(uploadButton, 'linear-gradient(45deg, #667eea, #764ba2)');
  uploadButton.mousePressed(() => fileInput.elt.click());
  
  playButton = createButton('💫 Awaken the Cosmos');
  playButton.position(30, 80);
  styleButton(playButton, 'linear-gradient(45deg, #f093fb, #f5576c)');
  playButton.mousePressed(togglePlayback);
  playButton.hide();

  fft = new p5.FFT(0.9, 128);
  amplitude = new p5.Amplitude();
  createStars();
  createConnections();
}

function draw() {
  drawGradientBackground();
  if (isPlaying && songLoaded) {
    let spectrum = fft.analyze();
    let level = amplitude.getLevel();

    for (let i = 0; i < stars.length; i++) {
      stars[i].update(level, spectrum);
      stars[i].display();
    }
    
    drawConnections(level);
  } else {
    for (let star of stars) {
      star.display();
    }
    drawConnections(0);
    
    if (!songLoaded) {
      drawCosmicMessage();
    }
  }
}

function styleButton(button, gradient) {
  button.style('background', gradient);
  button.style('color', '#fff');
  button.style('border', 'none');
  button.style('padding', '12px 24px');
  button.style('border-radius', '25px');
  button.style('font-family', 'Arial, sans-serif');
  button.style('font-size', '14px');
  button.style('font-weight', 'bold');
  button.style('cursor', 'pointer');
  button.style('box-shadow', '0 8px 25px rgba(0,0,0,0.3), 0 0 20px rgba(255,255,255,0.1)');
  button.style('transition', 'all 0.3s ease');
  button.mouseOver(() => {
    button.style('transform', 'translateY(-3px) scale(1.05)');
    button.style('box-shadow', '0 12px 35px rgba(0,0,0,0.4), 0 0 30px rgba(255,255,255,0.2)');
  });
  button.mouseOut(() => {
    button.style('transform', 'translateY(0) scale(1)');
    button.style('box-shadow', '0 8px 25px rgba(0,0,0,0.3), 0 0 20px rgba(255,255,255,0.1)');
  });
}

function drawCosmicMessage() {
  push();
  fill(0, 0, 0, 120);
  noStroke();
  let messageWidth = 450;
  let messageHeight = 100;
  rect(width/2 - messageWidth/2, height/2 - messageHeight/2, messageWidth, messageHeight, 20);
  
  textAlign(CENTER, CENTER);
  textFont('Arial');
  fill(255, 255, 255, 200 + sin(millis() * 0.003) * 55); // Gentle pulsing
  textSize(24);
  textStyle(BOLD);
  text('🌌 Drop an Audio File to Awaken the Constellations', width/2, height/2 - 15); 
  fill(180, 200, 255, 180);
  textSize(14);
  textStyle(NORMAL);
  text('Let your music illuminate the cosmos', width/2, height/2 + 15);  
  pop();
}

function drawGradientBackground() {
  for (let y = 0; y <= height; y++) {
    let progress = map(y, 0, height, 0, 1);
    let topColor = color(15, 12, 41);    // Deep space blue
    let bottomColor = color(5, 5, 25);    // Almost black
    let gradientColor = lerpColor(topColor, bottomColor, progress);
    stroke(gradientColor);
    line(0, y, width, y);
  }
}

function createStars() {
  stars = [];
  let starCount = 200; // Simple fixed number
  for (let i = 0; i < starCount; i++) {
    stars.push(new Star());
  }
}

function createConnections() {
  connections = [];
  
  for (let i = 0; i < stars.length; i++) {
    for (let j = i + 1; j < stars.length; j++) {
      let distance = dist(stars[i].x, stars[i].y, stars[j].x, stars[j].y);
      if (distance < 150 && random() < 0.1) { // Only some nearby stars connect
        connections.push({star1: i, star2: j});
      }
    }
  }
}

function drawConnections(audioLevel) {
  for (let connection of connections) {
    let star1 = stars[connection.star1];
    let star2 = stars[connection.star2];
    
    for (let layer = 0; layer < 2; layer++) {
      let opacity = (30 + audioLevel * 150) * (1 - layer * 0.4);
      let thickness = 1.5 - layer * 0.7;
      stroke(120 + layer * 50, 180 + layer * 30, 255, opacity);
      strokeWeight(thickness);
      line(star1.x, star1.y, star2.x, star2.y);
    }
  }
}

class Star {
  constructor() {
    this.x = random(width);
    this.y = random(height);
    this.baseSize = random(2, 5);
    this.size = this.baseSize;
    this.brightness = random(100, 255);
    this.color = random([
      [255, 248, 220],
      [176, 224, 255],
      [255, 180, 120],
      [230, 130, 255], 
      [120, 255, 200], 
      [255, 200, 200], 
      [200, 255, 255]  
    ]);
  }
  
  update(audioLevel, spectrum) {
    if (spectrum.length > 0) {
      let freqIndex = floor(map(this.x, 0, width, 0, spectrum.length - 1));
      let freq = spectrum[freqIndex] / 255;
      
      this.size = this.baseSize * (1 + freq * 2);
      this.brightness = 100 + freq * 155 + audioLevel * 100;
    } else {
      this.size = this.baseSize;
      this.brightness = random(100, 200);
    }
  }
  
  display() {
    push();
    translate(this.x, this.y);
    
    for (let glow = 3; glow >= 0; glow--) {
      let glowSize = this.size * (2 + glow * 0.8);
      let glowAlpha = (this.brightness * 0.15) / (glow + 1);
      fill(this.color[0], this.color[1], this.color[2], glowAlpha);
      noStroke();
      ellipse(0, 0, glowSize);
    }
    
    fill(this.color[0], this.color[1], this.color[2], this.brightness);
    ellipse(0, 0, this.size);
    
    if (this.brightness > 180) {
      stroke(255, 255, 255, this.brightness * 0.6);
      strokeWeight(0.8);
      let sparkleSize = this.size * 1.2;
      line(-sparkleSize, 0, sparkleSize, 0);
      line(0, -sparkleSize, 0, sparkleSize);
    }
    
    pop();
  }
}

function handleFile(file) {
  if (file.type === 'audio') {
    // Stop any existing song
    if (song && song.isPlaying()) {
      song.stop();
    }
    
    song = loadSound(file.data, () => {
      songLoaded = true;
      playButton.show();
      playButton.html('💫 Awaken the Cosmos');
      
      if (fft) fft.setInput(song);
      if (amplitude) amplitude.setInput(song);
      
      song.onended(() => {
        isPlaying = false;
        playButton.html('💫 Awaken the Cosmos');
      });
      
    }, (error) => {
      console.error('Audio loading failed:', error);
      songLoaded = false;
      playButton.hide();
    });
  }
}

function togglePlayback() {
  if (songLoaded && song && song.isLoaded()) {
    ensureAudioUnlocked(() => {
      if (song.isPlaying()) {
        song.pause();
        isPlaying = false;
        playButton.html('🌟 Awaken the Cosmos');
      } else {
        song.play();
        isPlaying = true;
        playButton.html('⏸️ Pause the Magic');
      }
    });
  }
}

function ensureAudioUnlocked(callback) {
  if (audioUnlocked) {
    return callback();
  }
  
  userStartAudio().then(() => {
    audioUnlocked = true;
    callback();
  }).catch(() => {
    try {
      getAudioContext().resume();
      audioUnlocked = true;
    } catch(e) {
      console.log('Audio context unlock failed');
    }
    callback();
  });
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  createStars();
  createConnections();
}